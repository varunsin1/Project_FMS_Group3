let player1;
let player2;
let ball;

let score1 = 0;
let score2 = 0;
let back;
let lose;


function preload(){
  back = loadImage("Background.jpg");
  }

function setup() {
  
  createCanvas(400, 400);
  rectMode(CENTER);
  player2= new Paddle(10);
  player1 = new Paddle(390);
  ball = new Ball();
}

function keyPressed()
{
  if(keyCode ==UP_ARROW)
  {
    player1.change_dir(-2);
  }
  
    if(keyCode ==DOWN_ARROW)
  {
    player1.change_dir(2);
  }
  
   if(keyCode ==87)
  {
    player2.change_dir(-2);
  }
  
    if(keyCode ==83)
  {
    player2.change_dir(2);
  }
  if (keyCode === 32 && y == 161) {
    if(lose){
      resetGame();
    }
  } 
  if(keyIsPressed && lose){
    resetGame();
  }
}
  
function resetGame(){
  score1 = 0;
  score2 = 0;
  lose = false;
  player2= new Paddle(10);
  player1 = new Paddle(390);
  ball = new Ball();
  ball.reset();
  player2.show();
  player1.show();
  player2.move();
  player1.move();
  player1.update();
  player2.update();
  ball.show();
  ball.move();
  ball.update();
  loop();
  keyPressed();
  
}
function draw() {
  image(back,0,0,back.width,back.height);
  back.resize(440,0);
  textSize(20);
  text("Player 1",5,50)
  text(score1,45,25);
  
  text("Player 2",320,50)
  text(score2,340,25);
  
  player2.show();
  player1.show();
  player2.move();
  player1.move();
  player1.update();
  player2.update();
  ball.show();
  ball.move();
  ball.update();
  
  //if ball goes outside
  if (ball.x>=width)
  {
    score1++
    ball.reset();
  }
  
    if (ball.x<=0)
  {
    score2++;
    ball.reset();
    
  }
  //detect collision
  
  if(ball.x>=380 && ball.y<=(player1.y+50) && ball.y>=(player1.y-50))
  {
    ball.vx *=-1;
  }
  
    if(ball.x<=20 && ball.y<=(player2.y+50) && ball.y>=(player2.y-50))
  {
    ball.vx *=-1;
  }
  
  
  if(score2 == 7 || score1 == 7){
    if(score2 == 7){
      text("Winner Player 2", 129, 120)
      text("Press Any Key to Reset",130,130)
      lose = true;
    }
    else{
      text("Winner Player 1", 129, 120)
      text("Press Any Key to Reset",100,150)
      lose = true;
    }
    
    noLoop();
  }
  
}