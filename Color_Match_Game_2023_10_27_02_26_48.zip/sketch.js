let order = [];
let playerOrder = [];
let flash;
let turn;
let good;
let compTurn;
let intervalId;
let on = false;
let win;

function setup() {
  createCanvas(700, 700);
  background(220);
  fill('purple')
  square(350,450,200)
  fill('blue')
  square(150,450,200)
  fill('red')
  square(350,250,200)
  fill(0, 200, 0, )
  square(150,250,200)
  textSize(50)
  fill('black')
  text("Color Match", 210, 100)
}

function draw() {
  
  
}
function play() {
  win = false;
  order = [];
  playerOrder = [];
  flash = 0;
  intervalId = 0;
  good = true;
  for (var i = 0; i < 20; i++) {
    order.push(Math.floor(Math.random() * 4) + 1);
  }
  compTurn = true;

  intervalId = setInterval(gameTurn, 800);
}

function gameTurn() {
  on = false;

  if (flash == turn) {
    clearInterval(intervalId);
    compTurn = false;
    clearColor();
    on = true;
  }

  if (compTurn) {
    clearColor();
    setTimeout(() => {
      if (order[flash] == 1) one();
      if (order[flash] == 2) two();
      if (order[flash] == 3) three();
      if (order[flash] == 4) four();
      flash++;
    }, 200);
  }
}
